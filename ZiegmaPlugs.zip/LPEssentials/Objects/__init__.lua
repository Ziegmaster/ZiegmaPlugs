_G.Objects = {};

import (Framework.Path.Objects .. ".Races");
import (Framework.Path.Objects .. ".Deeds");
import (Framework.Path.Objects .. ".Bestiary");
import (Framework.Path.Objects .. ".Session");
import (Framework.Path.Objects .. ".PlayerTracker");