Objects.Races = {};
Objects.Races[65] = Texts.Bestiary.Locations.Elves;
Objects.Races[114] = Texts.Bestiary.Locations.Beornings;