Plugin.UI = {};

import (Framework.Path.UI .. ".MainWindow");
import (Framework.Path.UI .. ".AlertsWindow");